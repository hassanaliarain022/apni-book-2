/**
 * READORA — CENTRAL CONFIGURATION & CONTACT SETTINGS
 * All public contact details, brand identity, and site settings are stored here.
 */

const SITE_CONFIG = {
  brand: {
    name: "Readora",
    tagline: "Digital Books & Practical Guides",
    accentWord: "Readora.",
    year: 2026,
    canonicalDomain: "http://localhost:8080"
  },
  
  contact: {
    displayPhone: "03374693712",
    internationalPhone: "+92 337 4693712",
    phoneLink: "tel:+923374693712",
    email: "hassanaliarain006@gmail.com",
    emailLink: "mailto:hassanaliarain006@gmail.com",
    whatsAppLink: "https://wa.me/923374693712",
    whatsAppCtaPrefilled: "https://wa.me/923374693712?text=Hi%2C%20I%20would%20like%20to%20discuss%20a%20project."
  },

  theme: {
    paper: "#f8f7f4",
    cardBg: "#ffffff",
    ink: "#15151b",
    inkMuted: "#5e596b",
    accent: "#7957F5",
    accentLight: "#9d7df9",
    plum: "#573bc4",
    border: "#e4dce2"
  },

  motion: {
    defaultEnabled: true,
    storageKey: "readora_motion_preference",
    swarmDurationMs: 2200
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = SITE_CONFIG;
} else if (typeof window !== 'undefined') {
  window.SITE_CONFIG = SITE_CONFIG;
}
