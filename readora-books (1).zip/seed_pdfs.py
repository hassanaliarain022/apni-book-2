import os

def create_simple_pdf(filename, title, subtitle):
    # Minimal valid PDF 1.4 binary structure
    content = f"""%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>
endobj
4 0 obj
<< /Length 280 >>
stream
BT
/F1 26 Tf
72 710 Td
({title}) Tj
/F1 15 Tf
0 -36 Td
({subtitle}) Tj
/F1 12 Tf
0 -36 Td
(Thank you for purchasing this authentic Readora digital edition.) Tj
0 -20 Td
(This PDF guide is DRM-free for your personal use across all your devices.) Tj
0 -36 Td
(Readora Digital Books - All Rights Reserved 2026.) Tj
ET
endstream
endobj
5 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
xref
0 6
0000000000 65535 f
0000000009 00000 n
0000000058 00000 n
0000000115 00000 n
0000000242 00000 n
0000000574 00000 n
trailer
<< /Size 6 /Root 1 0 R >>
startxref
645
%%EOF
"""
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, 'wb') as f:
        f.write(content.encode('latin1'))

books = [
    ('small-habits.pdf', 'Readora - Small Habits', 'Atomic Routines & Compound Progress'),
    ('find-your-voice.pdf', 'Readora - Find Your Voice', 'High-Stakes Communication & Speech'),
    ('the-first-step.pdf', 'Readora - The First Step', 'Freelancing Roadmap & Client Retainers'),
    ('deep-focus.pdf', 'Readora - Deep Focus', 'Eliminating Digital Distractions'),
    ('daily-creator.pdf', 'Readora - The Daily Creator', 'Systematic Publishing & Creative Leverage'),
    ('master-your-mind.pdf', 'Readora - Master Your Mind', 'Mental Models for Decision Making')
]

for fn, t, sub in books:
    create_simple_pdf(os.path.join('storage', 'private_pdfs', fn), t, sub)
    create_simple_pdf(os.path.join('storage', 'sample_pdfs', 'sample-' + fn), t + ' (Sample Preview)', sub)

print('Generated all real PDF files in storage/private_pdfs and storage/sample_pdfs')
