import requests
import json

BASE_URL = "http://localhost:8080"
session = requests.Session()

print("--- 1. Testing Storefront & Config ---")
r_root = session.get(f"{BASE_URL}/")
print(f"GET / : Status {r_root.status_code}, Length {len(r_root.text)}")
assert r_root.status_code == 200, "Root page failed"

r_cfg = session.get(f"{BASE_URL}/config.js")
print(f"GET /config.js : Status {r_cfg.status_code}, Contains SITE_CONFIG: {'SITE_CONFIG' in r_cfg.text}")
assert r_cfg.status_code == 200

r_books = session.get(f"{BASE_URL}/api/books/storefront")
books_data = r_books.json()
print(f"GET /api/books/storefront : Found {len(books_data.get('books', []))} books")
assert len(books_data.get("books", [])) >= 6

print("\n--- 2. Testing Owner Admin Authentication ---")
# Test bad password
r_bad = session.post(f"{BASE_URL}/api/admin/login", json={"username": "admin", "password": "WrongPassword"})
print(f"Login with bad password: {r_bad.status_code} (Expected 401)")
assert r_bad.status_code == 401

# Test good login
r_login = session.post(f"{BASE_URL}/api/admin/login", json={"username": "admin", "password": "Admin@Readora2026!"})
print(f"Login with valid credentials: {r_login.status_code}")
assert r_login.status_code == 200
login_json = r_login.json()
token = login_json["token"]
headers = {"Authorization": f"Bearer {token}"}

r_me = session.get(f"{BASE_URL}/api/admin/me", headers=headers)
print(f"GET /api/admin/me: {r_me.json()}")
assert r_me.status_code == 200

print("\n--- 3. Testing Admin Dashboard Analytics & KPIs ---")
r_dash = session.get(f"{BASE_URL}/api/admin/dashboard?timeframe=30d", headers=headers)
print(f"Dashboard response status: {r_dash.status_code}")
dash_data = r_dash.json()
sales = dash_data.get("sales", {})
traffic = dash_data.get("traffic", {})
print(f"Gross Sales: {sales.get('gross_sales')}, Net Revenue: {sales.get('net_collected_revenue')}, Total Orders: {sales.get('total_orders')}")
print(f"Explanation of Net Revenue: {sales.get('revenue_calculation_note')}")
print(f"Conversion rate formula: {traffic.get('conversion_formula')}")

print("\n--- 4. Testing Website Messages (Contact Form) ---")
contact_payload = {
    "name": "Sarah Connor",
    "email": "sarah.connor@example.com",
    "phone": "+923001234567",
    "subject": "Question about Deep Focus PDF",
    "message": "Does this guide include the Notion productivity dashboard template mentioned in chapter 3?"
}
r_contact = requests.post(f"{BASE_URL}/api/contact", json=contact_payload)
print(f"POST /api/contact: {r_contact.status_code}, response: {r_contact.json()}")
assert r_contact.status_code == 200

# Verify in Admin Messages
r_msgs = session.get(f"{BASE_URL}/api/admin/messages", headers=headers)
msgs = r_msgs.json().get("messages", [])
print(f"Admin Inbox count: {len(msgs)}, latest sender: {msgs[0]['name'] if msgs else 'none'}")
assert any(m["email"] == "sarah.connor@example.com" for m in msgs)
msg_id = [m["id"] for m in msgs if m["email"] == "sarah.connor@example.com"][0]

# Update message status to read + add admin notes
r_msg_up = session.put(f"{BASE_URL}/api/admin/messages/{msg_id}", json={"status": "read", "admin_notes": "Replied via email draft"}, headers=headers)
print(f"Update message {msg_id}: {r_msg_up.status_code}")
assert r_msg_up.status_code == 200

print("\n--- 5. Testing WhatsApp CTA Tracking ---")
# Track clicks from distinct sessions
requests.post(f"{BASE_URL}/api/track", json={
    "event_type": "whatsapp_click",
    "session_id": "sess_alpha_101",
    "placement": "floating_button",
    "book_title": "Deep Focus",
    "utm_source": "meta_ads",
    "utm_campaign": "productivity_q4"
})
requests.post(f"{BASE_URL}/api/track", json={
    "event_type": "whatsapp_click",
    "session_id": "sess_beta_202",
    "placement": "book_detail_modal",
    "book_title": "Small Habits",
    "utm_source": "meta_ads",
    "utm_campaign": "habits_launch"
})

r_wa = session.get(f"{BASE_URL}/api/admin/whatsapp", headers=headers)
wa_data = r_wa.json()
print(f"WhatsApp Tracking Summary: Total Clicks: {wa_data['summary']['total_clicks']}, Distinct Sessions: {wa_data['summary']['distinct_sessions']}")
print(f"Label: {wa_data['summary']['label']}")
print(f"Placements: {wa_data['placements']}")

print("\n--- 6. Testing Order Lifecycle & Private PDF Download Protection ---")
order_payload = {
    "customer_name": "Tariq Mahmood",
    "customer_email": "tariq.m@example.com",
    "customer_phone": "03009988776",
    "items": [
        {
            "book_id": 1,
            "slug": "small-habits",
            "title": "Small Habits",
            "price": 490,
            "qty": 1
        }
    ],
    "payment_method": "whatsapp_transfer",
    "notes": "Payment confirmed via WhatsApp direct chat",
    "utm_source": "facebook",
    "utm_campaign": "habits_promo",
    "session_id": "sess_tariq_01"
}
r_order = requests.post(f"{BASE_URL}/api/orders/create", json=order_payload)
print(f"POST /api/orders/create: {r_order.status_code}, response: {r_order.json()}")
assert r_order.status_code == 200
order_id = r_order.json()["order_id"]

# Verify payment is still pending and download access is locked
r_orders_list = session.get(f"{BASE_URL}/api/admin/orders", headers=headers)
orders = r_orders_list.json().get("orders", [])
matching_order = [o for o in orders if o["id"] == order_id][0]
print(f"Order #{order_id} initial payment_status: '{matching_order['payment_status']}', download_granted: {matching_order['download_granted']}")
assert matching_order["payment_status"] == "pending"
assert matching_order["download_granted"] == 0

# Confirm payment manually with admin audit trail
r_confirm = session.post(f"{BASE_URL}/api/admin/orders/{order_id}/confirm-payment", headers=headers)
print(f"Confirm Payment for Order #{order_id}: {r_confirm.status_code}")
assert r_confirm.status_code == 200
confirmed_data = r_confirm.json()
download_token = confirmed_data["download_token"]
download_url = confirmed_data["download_url"]
print(f"Download link generated: {download_url} (Token: {download_token})")

# Test downloading the PDF with the authorized token
r_download = session.get(f"{BASE_URL}/download/{download_token}")
print(f"GET /download/{download_token}: Status {r_download.status_code}, Content-Type: {r_download.headers.get('content-type')}, Size: {len(r_download.content)} bytes")
assert r_download.status_code == 200
assert "application/pdf" in r_download.headers.get("content-type", "")
assert len(r_download.content) > 500, "Downloaded PDF content is too small"

# Test invalid download token
r_bad_token = session.get(f"{BASE_URL}/download/invalid-token-12345")
print(f"GET /download/invalid-token-12345: {r_bad_token.status_code} (Expected 404)")
assert r_bad_token.status_code == 404

print("\n--- 7. Testing CSV Export & Audit Trail ---")
r_csv = session.get(f"{BASE_URL}/api/admin/orders/export/csv", headers=headers)
print(f"GET /api/admin/orders/export/csv: Status {r_csv.status_code}, Lines: {len(r_csv.text.splitlines())}")
assert r_csv.status_code == 200
assert "Order ID,Customer Name,Email" in r_csv.text

r_audit = session.get(f"{BASE_URL}/api/admin/audit-logs", headers=headers)
logs = r_audit.json().get("audit_logs", [])
print(f"Audit log entries recorded: {len(logs)}")
for l in logs[:3]:
    print(f" - [{l['created_at']}] {l['action']} on {l['entity_type']} by {l['username']}: {l['details']}")
assert len(logs) > 0

print("\n--- 8. Testing Meta Pixel & CAPI Settings & Diagnostics ---")
r_meta = session.get(f"{BASE_URL}/api/admin/integrations/meta", headers=headers)
meta_res = r_meta.json()
print(f"Meta Status: {meta_res['status']}")

print("\nALL BACKEND & LIFECYCLE TESTS PASSED PERFECTLY!")
