/*
  Readora Clone – Interaction Scripts (fixed location)
  Handles:
  • 3‑book carousel with auto‑play/pause, manual controls, touch swipes
  • Shelf carousel with scroll‑sync and pointer‑tilt effects
  • Mobile menu toggle
  • Reduced‑motion support
*/

// Mobile menu toggle
document.querySelector('.mobile').onclick = e => {
  const nav = document.getElementById('links');
  e.currentTarget.setAttribute('aria-expanded', String(nav.classList.toggle('open')));
};

// 3‑Book carousel (bookInteractions)
(function bookInteractions(){
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const controller = new AbortController();
  const options = { signal: controller.signal };
  const stage = document.querySelector('.cover-stage');
  if (!stage) return;
  const books = [...stage.querySelectorAll('.show-book')];
  const counter = stage.querySelector('.edition-counter');
  const title = stage.querySelector('.edition-title');
  let current = 0;
  const choose = index => {
    current = (index + books.length) % books.length;
    books.forEach((book, i) => {
      const offset = (i - current + books.length) % books.length;
      book.dataset.position = offset === 0 ? 'center' : offset === 1 ? 'right' : 'left';
    });
    const active = books[current];
    counter.textContent = String(current + 1).padStart(2, '0') + ' / ' + String(books.length).padStart(2, '0');
    title.textContent = active.dataset.title;
    title.href = active.href;
  };
  if (books.length > 1) {
    stage.querySelector('.stage-controls').hidden = false;
    const playBtn = stage.querySelector('.show-play');
    let playing = !reduce.matches, hovering = false, visible = false, timer;
    const schedule = () => {
      clearTimeout(timer);
      playBtn.textContent = playing ? 'Ⅱ' : '▶';
      playBtn.setAttribute('aria-label', playing ? 'Pause slideshow' : 'Play slideshow');
      if (playing && visible && !hovering && !document.hidden && !reduce.matches) {
        timer = setTimeout(() => { choose(current + 1); schedule(); }, 4800);
      }
    };
    const stop = () => { playing = false; schedule(); };
    playBtn.addEventListener('click', () => { playing = !playing; schedule(); }, options);
    for (const ctrl of stage.querySelectorAll('.show-prev,.show-next'))
      ctrl.addEventListener('click', stop, options);
    stage.addEventListener('pointerenter', e => { if (e.pointerType === 'mouse') { hovering = true; schedule(); } }, options);
    stage.addEventListener('pointerleave', () => { hovering = false; schedule(); }, options);
    stage.addEventListener('focusin', e => { if (e.target !== playBtn) stop(); }, options);
    stage.addEventListener('touchstart', e => { if (e.target !== playBtn) stop(); }, { ...options, passive:true });
    const visibility = new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; schedule(); });
    visibility.observe(stage);
    document.addEventListener('visibilitychange', schedule, options);
    const pref = () => { playBtn.hidden = reduce.matches; if (reduce.matches) playing = false; schedule(); };
    reduce.addEventListener('change', pref, options);
    pref();
    addEventListener('pagehide', e => { clearTimeout(timer); if (!e.persisted) visibility.disconnect(); }, options);
    addEventListener('pageshow', schedule, options);
    stage.querySelector('.show-prev').addEventListener('click', () => choose(current - 1), options);
    stage.querySelector('.show-next').addEventListener('click', () => choose(current + 1), options);
    let touch;
    stage.addEventListener('touchstart', e => { touch = e.touches.length === 1 ? e.touches[0] : null; }, { ...options, passive:true });
    stage.addEventListener('touchend', e => {
      if (!touch) return;
      const end = e.changedTouches[0];
      const dx = end.clientX - touch.clientX;
      const dy = end.clientY - touch.clientY;
      touch = null;
      if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.6) choose(current + (dx < 0 ? 1 : -1));
    }, { ...options, passive:true });
  }
})();

// Shelf carousel with tilt & scroll sync
(function shelfCarousel(){
  const shelf = document.querySelector('.shelf-cinema');
  if (!shelf) return;
  const pin = shelf.querySelector('.shelf-pin');
  const viewport = shelf.querySelector('.shelf-window');
  const mobile = matchMedia('(max-width:760px)');
  const header = document.querySelector('.top');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const controller = new AbortController();
  const options = { signal: controller.signal };
  let top = 0, distance = 0, pending = 0;
  const paint = () => {
    pending = 0;
    if (!shelf.classList.contains('shelf-follow')) return;
    viewport.scrollLeft = Math.max(0, Math.min(distance, top - shelf.getBoundingClientRect().top));
  };
  const schedule = () => { if (!pending) pending = requestAnimationFrame(paint); };
  const measure = () => {
    const wasActive = shelf.classList.contains('shelf-follow');
    top = Math.ceil(header.getBoundingClientRect().height);
    distance = Math.max(0, viewport.scrollWidth - viewport.clientWidth);
    const height = pin.offsetHeight;
    const eligible = mobile.matches && !reduce.matches && distance > 1 && height + top + 8 <= window.innerHeight;
    shelf.classList.toggle('shelf-follow', eligible);
    if (eligible) {
      shelf.style.setProperty('--pin-top', top + 'px');
      shelf.style.setProperty('--pin-range', (height + distance) + 'px');
    } else if (wasActive) {
      shelf.style.removeProperty('--pin-range');
      shelf.style.removeProperty('--pin-top');
    }
    schedule();
  };
  const observer = new ResizeObserver(measure);
  [pin, header, viewport, shelf.querySelector('.shelf-track')].forEach(node => observer.observe(node));
  addEventListener('resize', measure, options);
  addEventListener('scroll', schedule, { ...options, passive:true });
  reduce.addEventListener('change', measure, options);
  mobile.addEventListener('change', measure, options);
  viewport.addEventListener('focusin', e => {
    if (!shelf.classList.contains('shelf-follow') || !e.target.matches(':focus-visible')) return;
    const card = e.target.closest('.card');
    if (!card) return;
    const delta = card.getBoundingClientRect().left - viewport.getBoundingClientRect().left;
    const pos = Math.min(distance, Math.max(0, viewport.scrollLeft + delta));
    window.scrollTo({ top: scrollY + shelf.getBoundingClientRect().top - top + pos, behavior: 'instant' });
  }, options);
  measure();
  addEventListener('pageshow', measure, options);
  addEventListener('pagehide', e => { if (!e.persisted) observer.disconnect(); }, options);
})();

// Tilt effect on cards (pointer devices)
if (matchMedia('(pointer:fine)').matches) {
  document.querySelectorAll('.shelf-cinema .art').forEach(art => {
    let bounds;
    const reduce = matchMedia('(prefers-reduced-motion: reduce)');
    art.addEventListener('pointerenter', () => bounds = art.getBoundingClientRect());
    art.addEventListener('pointermove', e => {
      if (!bounds || reduce.matches) return;
      art.style.setProperty('--tilt-y', ((e.clientX - bounds.left) / bounds.width * 16 - 8) + 'deg');
      art.style.setProperty('--tilt-x', (7 - (e.clientY - bounds.top) / bounds.height * 14) + 'deg');
    });
    art.addEventListener('pointerleave', () => { art.style.removeProperty('--tilt-x'); art.style.removeProperty('--tilt-y'); });
  });
}

addEventListener('pagehide', e => { if (!e.persisted) controller.abort(); });
