"""
Meta Pixel & Conversions API (CAPI) Integration Module.
Implements server-side CAPI event dispatch, deduplication with browser pixel,
and diagnostic status reporting.
"""
import requests
import hashlib
import time
import json
from datetime import datetime, timezone
from db import get_db

GRAPH_API_VERSION = "v19.0"

def hash_data(val: str) -> str:
    if not val:
        return ""
    clean = val.strip().lower()
    return hashlib.sha256(clean.encode('utf-8')).hexdigest()

def get_meta_config():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT key, value FROM settings WHERE key IN ('meta_pixel_id', 'meta_pixel_enabled', 'meta_capi_token', 'meta_test_event_code');")
    cfg = {row["key"]: row["value"] for row in cursor.fetchall()}
    conn.close()
    return {
        "pixel_id": cfg.get("meta_pixel_id", "").strip(),
        "enabled": cfg.get("meta_pixel_enabled", "0") == "1",
        "access_token": cfg.get("meta_capi_token", "").strip(),
        "test_event_code": cfg.get("meta_test_event_code", "").strip()
    }

def send_capi_event(
    event_name: str,
    event_id: str,
    event_time: int = None,
    user_data: dict = None,
    custom_data: dict = None,
    event_source_url: str = None
) -> dict:
    config = get_meta_config()
    
    # If not enabled or no token/pixel, report honest unconfigured status
    if not config["enabled"]:
        return {"status": "skipped", "message": "Meta tracking is disabled in settings"}
    if not config["pixel_id"] or not config["access_token"]:
        return {"status": "unconfigured", "message": "Pixel ID or CAPI Access Token is missing"}

    if not event_time:
        event_time = int(time.time())

    ud = {}
    if user_data:
        if user_data.get("email"):
            ud["em"] = [hash_data(user_data["email"])]
        if user_data.get("phone"):
            ud["ph"] = [hash_data(user_data["phone"])]
        if user_data.get("client_ip_address"):
            ud["client_ip_address"] = user_data["client_ip_address"]
        if user_data.get("client_user_agent"):
            ud["client_user_agent"] = user_data["client_user_agent"]

    event_payload = {
        "event_name": event_name,
        "event_time": event_time,
        "event_id": event_id,
        "action_source": "website",
        "user_data": ud
    }
    if event_source_url:
        event_payload["event_source_url"] = event_source_url
    if custom_data:
        event_payload["custom_data"] = custom_data

    payload = {
        "data": [event_payload]
    }
    if config["test_event_code"]:
        payload["test_event_code"] = config["test_event_code"]

    url = f"https://graph.facebook.com/{GRAPH_API_VERSION}/{config['pixel_id']}/events"
    headers = {
        "Authorization": f"Bearer {config['access_token']}",
        "Content-Type": "application/json"
    }

    try:
        resp = requests.post(url, json=payload, headers=headers, timeout=5)
        res_json = resp.json()
        if resp.status_code == 200:
            return {"status": "success", "response": res_json}
        else:
            return {"status": "error", "code": resp.status_code, "error": res_json.get("error", {})}
    except Exception as e:
        return {"status": "failure", "error": str(e)}

def test_meta_connection() -> dict:
    """Verifies whether the configured Pixel ID and Access Token are accepted by Graph API."""
    config = get_meta_config()
    if not config["pixel_id"]:
        return {"status": "missing_pixel", "message": "Meta Pixel ID is not configured"}
    if not config["access_token"]:
        return {"status": "missing_token", "message": "Meta Conversions API Token is not configured"}

    url = f"https://graph.facebook.com/{GRAPH_API_VERSION}/{config['pixel_id']}"
    headers = {"Authorization": f"Bearer {config['access_token']}"}
    try:
        resp = requests.get(url, headers=headers, timeout=5)
        data = resp.json()
        if resp.status_code == 200 and "id" in data:
            return {
                "status": "connected",
                "pixel_id": data.get("id"),
                "name": data.get("name", "Connected Pixel"),
                "is_live": True
            }
        else:
            err = data.get("error", {})
            return {
                "status": "error",
                "code": resp.status_code,
                "message": err.get("message", "Invalid credentials"),
                "is_live": False
            }
    except Exception as e:
        return {"status": "unreachable", "message": str(e), "is_live": False}
