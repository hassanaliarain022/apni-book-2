"""
Database layer for Readora Digital Books.
Uses SQLite for zero-configuration, robust server-side persistence.
"""
import sqlite3
import os
import hashlib
import secrets
import json
from datetime import datetime, timezone

DB_FILE = os.path.join(os.path.dirname(__file__), "readora.db")

def get_db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def hash_password(password: str, salt: str = None) -> str:
    if not salt:
        salt = secrets.token_hex(16)
    hashed = hashlib.sha256((salt + password).encode('utf-8')).hexdigest()
    return f"{salt}:{hashed}"

def verify_password(password: str, stored_hash: str) -> bool:
    try:
        salt, hashed = stored_hash.split(":", 1)
        expected = hashlib.sha256((salt + password).encode('utf-8')).hexdigest()
        return secrets.compare_digest(hashed, expected)
    except Exception:
        return False

def init_db():
    conn = get_db()
    cursor = conn.cursor()

    # Users / Admin table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'owner',
        recovery_token TEXT,
        recovery_expiry TEXT,
        created_at TEXT NOT NULL
    );
    """)

    # Books catalog table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS books (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        slug TEXT UNIQUE NOT NULL,
        title TEXT NOT NULL,
        author TEXT DEFAULT 'Readora Editorial',
        short_description TEXT NOT NULL,
        full_description TEXT NOT NULL,
        cover_style TEXT DEFAULT 'cover-emerald',
        cover_image TEXT,
        private_pdf_filename TEXT,
        sample_pdf_filename TEXT,
        price REAL NOT NULL,
        sale_price REAL,
        currency TEXT NOT NULL DEFAULT 'PKR',
        category TEXT NOT NULL,
        tags TEXT DEFAULT '',
        language TEXT DEFAULT 'English',
        page_count INTEGER DEFAULT 120,
        status TEXT NOT NULL DEFAULT 'published',
        is_featured INTEGER NOT NULL DEFAULT 1,
        display_order INTEGER NOT NULL DEFAULT 0,
        seo_title TEXT,
        seo_description TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    );
    """)

    # Orders table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS orders (
        id TEXT PRIMARY KEY,
        customer_name TEXT NOT NULL,
        customer_email TEXT NOT NULL,
        customer_phone TEXT,
        items_json TEXT NOT NULL,
        subtotal REAL NOT NULL,
        discount_amount REAL DEFAULT 0,
        refund_amount REAL DEFAULT 0,
        total_amount REAL NOT NULL,
        currency TEXT NOT NULL DEFAULT 'PKR',
        payment_method TEXT NOT NULL,
        payment_status TEXT NOT NULL DEFAULT 'pending',
        fulfillment_status TEXT NOT NULL DEFAULT 'unfulfilled',
        download_granted INTEGER NOT NULL DEFAULT 0,
        download_token TEXT UNIQUE,
        download_token_expiry TEXT,
        download_count INTEGER NOT NULL DEFAULT 0,
        notes TEXT,
        utm_source TEXT,
        utm_medium TEXT,
        utm_campaign TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    );
    """)

    # Customers table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        phone TEXT,
        total_orders INTEGER NOT NULL DEFAULT 0,
        total_spent REAL NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        last_order_at TEXT
    );
    """)

    # Messages inbox table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT,
        subject TEXT NOT NULL,
        message TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'new',
        admin_notes TEXT,
        ip_address TEXT,
        created_at TEXT NOT NULL
    );
    """)

    # Analytics Events table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_type TEXT NOT NULL,
        book_id INTEGER,
        book_title TEXT,
        page_url TEXT,
        session_id TEXT,
        placement TEXT,
        value REAL DEFAULT 0,
        currency TEXT DEFAULT 'PKR',
        meta_event_id TEXT,
        utm_source TEXT,
        utm_medium TEXT,
        utm_campaign TEXT,
        ip_address TEXT,
        user_agent TEXT,
        created_at TEXT NOT NULL
    );
    """)

    # Audit Logs table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        username TEXT NOT NULL,
        action TEXT NOT NULL,
        entity_type TEXT NOT NULL,
        entity_id TEXT,
        details TEXT,
        ip_address TEXT,
        created_at TEXT NOT NULL
    );
    """)

    # Settings Key-Value table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TEXT NOT NULL
    );
    """)

    conn.commit()

    # Seed Default Owner
    cursor.execute("SELECT id FROM users WHERE username = 'admin';")
    if not cursor.fetchone():
        now = datetime.now(timezone.utc).isoformat()
        initial_pw = "Admin@Readora2026!"
        cursor.execute(
            "INSERT INTO users (username, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?);",
            ("admin", "hassanaliarain006@gmail.com", hash_password(initial_pw), "owner", now)
        )
        cursor.execute(
            "INSERT INTO audit_logs (username, action, entity_type, entity_id, details, created_at) VALUES (?, ?, ?, ?, ?, ?);",
            ("system", "INITIAL_SETUP", "USER", "admin", "Initialized default owner account", now)
        )
        conn.commit()

    # Seed Default Settings
    default_settings = {
        "brand_name": "Readora",
        "tagline": "Digital Books & Practical Guides",
        "display_phone": "03374693712",
        "international_phone": "+92 337 4693712",
        "whatsapp_url": "https://wa.me/923374693712",
        "email": "hassanaliarain006@gmail.com",
        "currency": "PKR",
        "timezone": "Asia/Karachi",
        "meta_pixel_id": "",
        "meta_pixel_enabled": "0",
        "meta_capi_token": "",
        "meta_test_event_code": "",
        "download_token_expiry_hours": "72",
        "download_max_allowed": "10"
    }
    now = datetime.now(timezone.utc).isoformat()
    for k, v in default_settings.items():
        cursor.execute("INSERT OR IGNORE INTO settings (key, value, updated_at) VALUES (?, ?, ?);", (k, v, now))
    conn.commit()

    # Seed 6 Authentic Books if table is empty
    cursor.execute("SELECT COUNT(*) as cnt FROM books;")
    if cursor.fetchone()["cnt"] == 0:
        seed_books = [
            {
                "slug": "small-habits",
                "title": "Small Habits",
                "author": "Readora Editorial",
                "short_description": "Build effortless 2-minute compound routines anchored directly into your existing daily flow.",
                "full_description": "Built specifically for readers who struggle with consistency. Master the 2-minute habit anchor protocol, identity stacking, and friction elimination to automate long-term growth.",
                "cover_style": "c0",
                "private_pdf_filename": "small-habits.pdf",
                "sample_pdf_filename": "sample-small-habits.pdf",
                "price": 490.0,
                "sale_price": None,
                "currency": "PKR",
                "category": "habits",
                "tags": "Habits, Routines, Psychology, Productivity",
                "page_count": 128,
                "status": "published",
                "is_featured": 1,
                "display_order": 1,
                "seo_title": "Small Habits — Digital Edition | Readora",
                "seo_description": "Transform your daily trajectory with compound micro-habits."
            },
            {
                "slug": "find-your-voice",
                "title": "Find Your Voice",
                "author": "Readora Editorial",
                "short_description": "Command presence in meetings, interviews, and pitches without shouting or second-guessing.",
                "full_description": "For executives and builders who lose their words in high-pressure rooms. Learn how to structure high-conviction points, frame complex proposals, and speak with unwavering clarity.",
                "cover_style": "c1",
                "private_pdf_filename": "find-your-voice.pdf",
                "sample_pdf_filename": "sample-find-your-voice.pdf",
                "price": 590.0,
                "sale_price": None,
                "currency": "PKR",
                "category": "communication",
                "tags": "Communication, Public Speaking, Leadership",
                "page_count": 144,
                "status": "published",
                "is_featured": 1,
                "display_order": 2,
                "seo_title": "Find Your Voice — Public Speaking & Pitching | Readora",
                "seo_description": "Speak with clarity and command in every high-stakes meeting."
            },
            {
                "slug": "the-first-step",
                "title": "The First Step",
                "author": "Readora Editorial",
                "short_description": "From zero client experience to consistent retainer income. Proposals, pricing, and contracts.",
                "full_description": "A field-tested roadmap for new digital freelancers and independent consultants. Includes ready-to-use proposal templates, client vetting scripts, and retainer contracts.",
                "cover_style": "c2",
                "private_pdf_filename": "the-first-step.pdf",
                "sample_pdf_filename": "sample-the-first-step.pdf",
                "price": 690.0,
                "sale_price": None,
                "currency": "PKR",
                "category": "freelancing",
                "tags": "Freelancing, Career, Sales, Proposals",
                "page_count": 160,
                "status": "published",
                "is_featured": 1,
                "display_order": 3,
                "seo_title": "The First Step — Freelancing Playbook | Readora",
                "seo_description": "Launch and scale your independent client business."
            },
            {
                "slug": "deep-focus",
                "title": "Deep Focus",
                "author": "Readora Editorial",
                "short_description": "Eliminate digital distraction and accomplish more in 2 hours than most in an 8-hour workday.",
                "full_description": "A brutal breakdown of how modern algorithms steal cognition, alongside an actionable protocol to reclaim 4 continuous hours of uninterrupted, high-output flow.",
                "cover_style": "c3",
                "private_pdf_filename": "deep-focus.pdf",
                "sample_pdf_filename": "sample-deep-focus.pdf",
                "price": 550.0,
                "sale_price": None,
                "currency": "PKR",
                "category": "productivity",
                "tags": "Focus, Deep Work, Productivity",
                "page_count": 112,
                "status": "published",
                "is_featured": 1,
                "display_order": 4,
                "seo_title": "Deep Focus — Protocol for Uninterrupted Flow | Readora",
                "seo_description": "Master deep work and crush cognitive fatigue."
            },
            {
                "slug": "daily-creator",
                "title": "The Daily Creator",
                "author": "Readora Editorial",
                "short_description": "Systematize your creative thinking, publish compelling essays, and grow your digital audience.",
                "full_description": "How to turn curiosity into high-leverage content assets. Learn the architecture of viral hooks, structured newsletters, and long-form thought leadership.",
                "cover_style": "c4",
                "private_pdf_filename": "daily-creator.pdf",
                "sample_pdf_filename": "sample-daily-creator.pdf",
                "price": 620.0,
                "sale_price": None,
                "currency": "PKR",
                "category": "productivity",
                "tags": "Creativity, Writing, Audience Growth",
                "page_count": 136,
                "status": "published",
                "is_featured": 1,
                "display_order": 5,
                "seo_title": "The Daily Creator — Writing & Publishing System | Readora",
                "seo_description": "Build an unstoppable daily writing and publishing habit."
            },
            {
                "slug": "master-your-mind",
                "title": "Master Your Mind",
                "author": "Readora Editorial",
                "short_description": "Adopt mental models of history's greatest polymaths to solve complex business problems.",
                "full_description": "The 25 essential cognitive frameworks used by premier entrepreneurs and thinkers to evaluate asymmetric risk, eliminate bias, and make superior decisions.",
                "cover_style": "c5",
                "private_pdf_filename": "master-your-mind.pdf",
                "sample_pdf_filename": "sample-master-your-mind.pdf",
                "price": 750.0,
                "sale_price": None,
                "currency": "PKR",
                "category": "mindset",
                "tags": "Mental Models, Decision Making, Psychology",
                "page_count": 180,
                "status": "published",
                "is_featured": 1,
                "display_order": 6,
                "seo_title": "Master Your Mind — Mental Models for Decision Science | Readora",
                "seo_description": "Sharpen decision making with premier mental models."
            }
        ]
        for b in seed_books:
            cursor.execute("""
            INSERT INTO books (
                slug, title, author, short_description, full_description, cover_style,
                private_pdf_filename, sample_pdf_filename, price, sale_price, currency,
                category, tags, page_count, status, is_featured, display_order,
                seo_title, seo_description, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, (
                b["slug"], b["title"], b["author"], b["short_description"], b["full_description"],
                b["cover_style"], b["private_pdf_filename"], b["sample_pdf_filename"],
                b["price"], b["sale_price"], b["currency"], b["category"], b["tags"],
                b["page_count"], b["status"], b["is_featured"], b["display_order"],
                b["seo_title"], b["seo_description"], now, now
            ))
        conn.commit()

    conn.close()

if __name__ == "__main__":
    init_db()
    print("Database initialized successfully at:", DB_FILE)
