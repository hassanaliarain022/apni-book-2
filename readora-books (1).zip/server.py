"""
Readora Digital Books — Production Full-Stack Server
Provides Storefront, Protected Owner Admin API, SQLite Persistence,
Private PDF Tokenized Downloads, Meta CAPI, Analytics, and Order Management.
"""
import os
import sys
import json
import time
import secrets
import csv
import io
import urllib.parse
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict, Any

from fastapi import FastAPI, Request, Response, Depends, HTTPException, status, Query, UploadFile, File, Form
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr

from db import get_db, hash_password, verify_password, init_db
from meta_tracker import send_capi_event, test_meta_connection, get_meta_config

# Ensure database and directories are ready
init_db()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STORAGE_PRIVATE = os.path.join(BASE_DIR, "storage", "private_pdfs")
STORAGE_SAMPLES = os.path.join(BASE_DIR, "storage", "sample_pdfs")
STORAGE_COVERS = os.path.join(BASE_DIR, "storage", "covers")
PUBLIC_DIR = os.path.join(BASE_DIR, "public")

os.makedirs(STORAGE_PRIVATE, exist_ok=True)
os.makedirs(STORAGE_SAMPLES, exist_ok=True)
os.makedirs(STORAGE_COVERS, exist_ok=True)
os.makedirs(PUBLIC_DIR, exist_ok=True)

app = FastAPI(title="Readora Digital Books API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Active Admin Sessions in memory
SESSIONS: Dict[str, Dict[str, Any]] = {}

def get_current_admin(request: Request) -> Dict[str, Any]:
    # Check session cookie or Authorization header
    token = request.cookies.get("readora_admin_token")
    if not token and "Authorization" in request.headers:
        auth_header = request.headers["Authorization"]
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]

    if not token or token not in SESSIONS:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Unauthorized admin session. Please log in."
        )
    session = SESSIONS[token]
    # Check session expiry (8 hours)
    if time.time() > session["expires_at"]:
        del SESSIONS[token]
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Session expired")
    return session

def log_audit(action: str, entity_type: str, entity_id: str, details: str, username: str = "system", ip: str = ""):
    conn = get_db()
    cursor = conn.cursor()
    now = datetime.now(timezone.utc).isoformat()
    cursor.execute(
        "INSERT INTO audit_logs (username, action, entity_type, entity_id, details, ip_address, created_at) VALUES (?, ?, ?, ?, ?, ?, ?);",
        (username, action, entity_type, str(entity_id), details, ip, now)
    )
    conn.commit()
    conn.close()

# -------------------------------------------------------------
# PYDANTIC SCHEMAS
# -------------------------------------------------------------
class LoginRequest(BaseModel):
    username: str
    password: str

class PasswordRecoveryRequest(BaseModel):
    email: str

class PasswordResetConfirm(BaseModel):
    token: str
    new_password: str

class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str

class BookCreateUpdate(BaseModel):
    title: str
    slug: str
    author: Optional[str] = "Readora Editorial"
    short_description: str
    full_description: str
    cover_style: Optional[str] = "c0"
    cover_image: Optional[str] = None
    private_pdf_filename: Optional[str] = None
    sample_pdf_filename: Optional[str] = None
    price: float
    sale_price: Optional[float] = None
    currency: Optional[str] = "PKR"
    category: str
    tags: Optional[str] = ""
    language: Optional[str] = "English"
    page_count: Optional[int] = 120
    status: Optional[str] = "published"
    is_featured: Optional[int] = 1
    display_order: Optional[int] = 0
    seo_title: Optional[str] = None
    seo_description: Optional[str] = None

class OrderCreateRequest(BaseModel):
    customer_name: str
    customer_email: str
    customer_phone: Optional[str] = ""
    items: List[Dict[str, Any]]
    payment_method: str = "whatsapp_transfer"
    notes: Optional[str] = ""
    utm_source: Optional[str] = ""
    utm_medium: Optional[str] = ""
    utm_campaign: Optional[str] = ""
    session_id: Optional[str] = ""

class ContactRequest(BaseModel):
    name: str
    email: str
    phone: Optional[str] = ""
    subject: str
    message: str

class TrackEventRequest(BaseModel):
    event_type: str
    book_id: Optional[int] = None
    book_title: Optional[str] = None
    page_url: Optional[str] = None
    session_id: Optional[str] = None
    placement: Optional[str] = None
    value: Optional[float] = 0
    currency: Optional[str] = "PKR"
    meta_event_id: Optional[str] = None
    utm_source: Optional[str] = None
    utm_medium: Optional[str] = None
    utm_campaign: Optional[str] = None

class SettingsUpdateRequest(BaseModel):
    settings: Dict[str, str]

# -------------------------------------------------------------
# PUBLIC STOREFRONT & ASSET ROUTES
# -------------------------------------------------------------
@app.get("/", response_class=HTMLResponse)
async def serve_storefront():
    # Return the existing index.html
    index_path = os.path.join(BASE_DIR, "index.html")
    if os.path.exists(index_path):
        with open(index_path, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    return HTMLResponse("<h1>Readora Digital Books</h1><p>Storefront template missing.</p>")

@app.get("/config.js")
async def serve_dynamic_config():
    """Generates real-time config.js matching current settings in the database."""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT key, value FROM settings;")
    cfg = {row["key"]: row["value"] for row in cursor.fetchall()}
    conn.close()

    js_content = f"""/**
 * Readora Dynamic Central Configuration
 * Synchronized with Database Settings
 */
const SITE_CONFIG = {{
  brand: {{
    name: {json.dumps(cfg.get('brand_name', 'Readora'))},
    tagline: {json.dumps(cfg.get('tagline', 'Digital Books & Practical Guides'))},
    accentWord: "Readora.",
    year: 2026,
    canonicalDomain: "http://localhost:8080"
  }},
  contact: {{
    displayPhone: {json.dumps(cfg.get('display_phone', '03374693712'))},
    internationalPhone: {json.dumps(cfg.get('international_phone', '+92 337 4693712'))},
    phoneLink: "tel:" + {json.dumps(cfg.get('international_phone', '+92 337 4693712').replace(' ', ''))},
    email: {json.dumps(cfg.get('email', 'hassanaliarain006@gmail.com'))},
    emailLink: "mailto:" + {json.dumps(cfg.get('email', 'hassanaliarain006@gmail.com'))},
    whatsAppLink: {json.dumps(cfg.get('whatsapp_url', 'https://wa.me/923374693712'))},
    whatsAppCtaPrefilled: {json.dumps(cfg.get('whatsapp_url', 'https://wa.me/923374693712') + '?text=Hi%2C%20I%20would%20like%20to%20discuss%20a%20project.')}
  }},
  meta: {{
    pixelId: {json.dumps(cfg.get('meta_pixel_id', ''))},
    enabled: { 'true' if cfg.get('meta_pixel_enabled') == '1' else 'false' }
  }},
  theme: {{
    paper: "#f8f7f4",
    cardBg: "#ffffff",
    ink: "#15151b",
    inkMuted: "#5e596b",
    accent: "#7957F5",
    accentLight: "#9d7df9",
    plum: "#573bc4",
    border: "#e4dce2"
  }},
  motion: {{
    defaultEnabled: true,
    storageKey: "readora_motion_preference",
    swarmDurationMs: 2200
  }}
}};

if (typeof module !== 'undefined' && module.exports) {{
  module.exports = SITE_CONFIG;
}} else if (typeof window !== 'undefined') {{
  window.SITE_CONFIG = SITE_CONFIG;
}}
"""
    return Response(content=js_content, media_type="application/javascript")

@app.get("/api/books/storefront")
async def get_storefront_books():
    """Returns published books ordered by display_order for the storefront."""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, slug, title, author, short_description, full_description,
               cover_style, cover_image, sample_pdf_filename, price, sale_price,
               currency, category, tags, page_count, is_featured, display_order
        FROM books
        WHERE status = 'published'
        ORDER BY display_order ASC, id ASC;
    """)
    books = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return {"books": books}

@app.get("/api/books/detail/{slug}")
async def get_book_detail(slug: str):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM books WHERE slug = ? AND status != 'archived';", (slug,))
    book = cursor.fetchone()
    conn.close()
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    b = dict(book)
    del b["private_pdf_filename"] # Never leak private file path in public detail
    return {"book": b}

@app.get("/sample/{filename}")
async def download_sample_pdf(filename: str):
    safe_fn = os.path.basename(filename)
    path = os.path.join(STORAGE_SAMPLES, safe_fn)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Sample preview not found")
    return FileResponse(path, media_type="application/pdf", filename=safe_fn)

@app.get("/download/{token}")
async def download_private_pdf(token: str, request: Request):
    """
    Authorized, tokenized, expiring download of purchased private PDF.
    Verifies order paid status and expiry, increments download counter,
    and logs the download event.
    """
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT o.id, o.download_granted, o.download_token_expiry, o.download_count,
               o.items_json, o.payment_status, o.customer_email
        FROM orders o
        WHERE o.download_token = ?;
    """, (token,))
    order = cursor.fetchone()
    if not order:
        conn.close()
        raise HTTPException(status_code=404, detail="Invalid download token or order not found")

    if order["payment_status"] != "paid" or order["download_granted"] != 1:
        conn.close()
        raise HTTPException(status_code=403, detail="Download access is not unlocked. Payment is pending confirmation.")

    now_iso = datetime.now(timezone.utc).isoformat()
    if order["download_token_expiry"] and now_iso > order["download_token_expiry"]:
        conn.close()
        raise HTTPException(status_code=410, detail="This download link has expired. Please contact support.")

    # Parse items to find file
    try:
        items = json.loads(order["items_json"])
    except Exception:
        items = []

    if not items:
        conn.close()
        raise HTTPException(status_code=404, detail="No downloadable items associated with this order")

    # Pick first book in order
    first_item = items[0]
    book_slug = first_item.get("slug")
    cursor.execute("SELECT private_pdf_filename, title FROM books WHERE slug = ?;", (book_slug,))
    book = cursor.fetchone()

    pdf_filename = book["private_pdf_filename"] if book and book["private_pdf_filename"] else "small-habits.pdf"
    file_path = os.path.join(STORAGE_PRIVATE, pdf_filename)

    if not os.path.exists(file_path):
        conn.close()
        raise HTTPException(status_code=404, detail="Private file is currently unavailable on server storage")

    # Increment download count
    cursor.execute("UPDATE orders SET download_count = download_count + 1, updated_at = ? WHERE id = ?;", (now_iso, order["id"]))
    
    # Log download event
    cursor.execute("""
        INSERT INTO events (event_type, book_title, value, currency, ip_address, created_at)
        VALUES ('download', ?, 0, 'PKR', ?, ?);
    """, (book["title"] if book else book_slug, request.client.host if request.client else "", now_iso))
    conn.commit()
    conn.close()

    return FileResponse(file_path, media_type="application/pdf", filename=pdf_filename)

# -------------------------------------------------------------
# EVENT TRACKING & CONTACT APIS
# -------------------------------------------------------------
@app.post("/api/track")
async def track_event(data: TrackEventRequest, request: Request):
    """
    Privacy-aware website analytics event logger.
    Deduplicates with Meta CAPI if configured.
    """
    conn = get_db()
    cursor = conn.cursor()
    now_iso = datetime.now(timezone.utc).isoformat()
    ip = request.client.host if request.client else ""
    ua = request.headers.get("user-agent", "")

    cursor.execute("""
        INSERT INTO events (
            event_type, book_id, book_title, page_url, session_id, placement,
            value, currency, meta_event_id, utm_source, utm_medium, utm_campaign,
            ip_address, user_agent, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    """, (
        data.event_type, data.book_id, data.book_title, data.page_url, data.session_id,
        data.placement, data.value or 0, data.currency or "PKR", data.meta_event_id,
        data.utm_source, data.utm_medium, data.utm_campaign, ip, ua, now_iso
    ))
    conn.commit()
    conn.close()

    # Meta CAPI Dispatch for standard events
    capi_result = None
    meta_name_map = {
        "page_view": "PageView",
        "view_content": "ViewContent",
        "add_to_cart": "AddToCart",
        "initiate_checkout": "InitiateCheckout",
        "purchase": "Purchase",
        "contact_submit": "Lead"
    }
    if data.event_type in meta_name_map:
        ev_id = data.meta_event_id or f"ev_{secrets.token_hex(8)}"
        custom_data = {}
        if data.value:
            custom_data["value"] = data.value
            custom_data["currency"] = data.currency or "PKR"
        if data.book_title:
            custom_data["content_name"] = data.book_title

        capi_result = send_capi_event(
            event_name=meta_name_map[data.event_type],
            event_id=ev_id,
            user_data={"client_ip_address": ip, "client_user_agent": ua},
            custom_data=custom_data if custom_data else None,
            event_source_url=data.page_url
        )

    return {"status": "recorded", "event_type": data.event_type, "capi": capi_result}

@app.post("/api/contact")
async def submit_contact(req: ContactRequest, request: Request):
    """Saves website message directly into persistent database inbox."""
    conn = get_db()
    cursor = conn.cursor()
    now_iso = datetime.now(timezone.utc).isoformat()
    ip = request.client.host if request.client else ""

    cursor.execute("""
        INSERT INTO messages (name, email, phone, subject, message, status, ip_address, created_at)
        VALUES (?, ?, ?, ?, ?, 'new', ?, ?);
    """, (req.name.strip(), req.email.strip().lower(), req.phone.strip(), req.subject.strip(), req.message.strip(), ip, now_iso))
    msg_id = cursor.lastrowid

    # Log event
    cursor.execute("""
        INSERT INTO events (event_type, page_url, ip_address, created_at)
        VALUES ('contact_submit', '/#contact', ?, ?);
    """, (ip, now_iso))
    conn.commit()
    conn.close()

    return {"status": "success", "message_id": msg_id, "detail": "Message saved to inbox"}

@app.post("/api/orders/create")
async def create_order(req: OrderCreateRequest, request: Request):
    """
    Creates customer order with server-side validation.
    Calculates subtotal, generates order ID, and associates customer.
    """
    conn = get_db()
    cursor = conn.cursor()
    now_iso = datetime.now(timezone.utc).isoformat()

    if not req.items:
        conn.close()
        raise HTTPException(status_code=400, detail="Order items cannot be empty")

    subtotal = sum(float(item.get("price", 0)) * int(item.get("qty", 1)) for item in req.items)
    discount = 0.0
    total = subtotal - discount

    # Generate sequential or unique Order ID: ORD-YYYY-XXXX
    order_num = secrets.randbelow(9000) + 1000
    order_id = f"ORD-{datetime.now().year}-{order_num}"

    # Default to pending. Download token is generated ahead of time
    download_token = secrets.token_urlsafe(24)
    # 72 hours expiry
    expiry = (datetime.now(timezone.utc) + timedelta(hours=72)).isoformat()

    cursor.execute("""
        INSERT INTO orders (
            id, customer_name, customer_email, customer_phone, items_json,
            subtotal, discount_amount, refund_amount, total_amount, currency,
            payment_method, payment_status, fulfillment_status, download_granted,
            download_token, download_token_expiry, notes, utm_source, utm_medium, utm_campaign,
            created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, 'PKR', ?, 'pending', 'unfulfilled', 0, ?, ?, ?, ?, ?, ?, ?, ?);
    """, (
        order_id, req.customer_name.strip(), req.customer_email.strip().lower(),
        req.customer_phone.strip(), json.dumps(req.items), subtotal, discount,
        total, req.payment_method, download_token, expiry, req.notes,
        req.utm_source, req.utm_medium, req.utm_campaign, now_iso, now_iso
    ))

    # Update or insert customer
    cursor.execute("SELECT id FROM customers WHERE email = ?;", (req.customer_email.strip().lower(),))
    existing_c = cursor.fetchone()
    if existing_c:
        cursor.execute("UPDATE customers SET total_orders = total_orders + 1, last_order_at = ? WHERE id = ?;", (now_iso, existing_c["id"]))
    else:
        cursor.execute(
            "INSERT INTO customers (name, email, phone, total_orders, total_spent, created_at, last_order_at) VALUES (?, ?, ?, 1, 0, ?, ?);",
            (req.customer_name.strip(), req.customer_email.strip().lower(), req.customer_phone.strip(), now_iso, now_iso)
        )

    # Track checkout event
    ip = request.client.host if request.client else ""
    cursor.execute("""
        INSERT INTO events (event_type, value, currency, session_id, utm_source, utm_medium, utm_campaign, ip_address, created_at)
        VALUES ('initiate_checkout', ?, 'PKR', ?, ?, ?, ?, ?, ?);
    """, (total, req.session_id, req.utm_source, req.utm_medium, req.utm_campaign, ip, now_iso))

    conn.commit()
    conn.close()

    return {
        "status": "created",
        "order_id": order_id,
        "total": total,
        "currency": "PKR",
        "payment_method": req.payment_method,
        "whatsapp_url": f"https://wa.me/923374693712?text={urllib.parse.quote(f'Hi Readora, I created order {order_id} for PKR {total}. Please confirm payment.')}"
    }

# -------------------------------------------------------------
# PROTECTED OWNER ADMIN APIS
# -------------------------------------------------------------
@app.post("/api/admin/login")
async def admin_login(creds: LoginRequest, response: Response, request: Request):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, email, password_hash, role FROM users WHERE username = ? OR email = ?;", (creds.username.strip(), creds.username.strip().lower()))
    user = cursor.fetchone()
    conn.close()

    if not user or not verify_password(creds.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid username or password")

    # Create session
    token = secrets.token_hex(24)
    expires_at = time.time() + (8 * 3600) # 8 hours
    SESSIONS[token] = {
        "user_id": user["id"],
        "username": user["username"],
        "email": user["email"],
        "role": user["role"],
        "expires_at": expires_at
    }

    response.set_cookie(
        key="readora_admin_token",
        value=token,
        max_age=8 * 3600,
        httponly=True,
        samesite="lax"
    )

    log_audit("LOGIN", "USER", user["username"], "Admin logged in successfully", user["username"], request.client.host if request.client else "")

    return {
        "status": "authenticated",
        "token": token,
        "user": {
            "id": user["id"],
            "username": user["username"],
            "email": user["email"],
            "role": user["role"]
        }
    }

@app.post("/api/admin/logout")
async def admin_logout(response: Response, current_user: Dict = Depends(get_current_admin)):
    response.delete_cookie("readora_admin_token")
    return {"status": "logged_out"}

@app.get("/api/admin/me")
async def admin_me(current_user: Dict = Depends(get_current_admin)):
    return {"user": current_user}

@app.post("/api/admin/change-password")
async def change_password(data: ChangePasswordRequest, request: Request, current_user: Dict = Depends(get_current_admin)):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT password_hash FROM users WHERE id = ?;", (current_user["user_id"],))
    user = cursor.fetchone()

    if not user or not verify_password(data.old_password, user["password_hash"]):
        conn.close()
        raise HTTPException(status_code=400, detail="Current password is incorrect")

    if len(data.new_password) < 8:
        conn.close()
        raise HTTPException(status_code=400, detail="New password must be at least 8 characters")

    new_hash = hash_password(data.new_password)
    cursor.execute("UPDATE users SET password_hash = ? WHERE id = ?;", (new_hash, current_user["user_id"]))
    conn.commit()
    conn.close()

    log_audit("CHANGE_PASSWORD", "USER", current_user["username"], "Owner password updated", current_user["username"], request.client.host if request.client else "")
    return {"status": "success", "message": "Password changed successfully"}

@app.post("/api/admin/recover-password")
async def recover_password(req: PasswordRecoveryRequest, request: Request):
    """
    Generates a password recovery token and returns an actionable recovery link.
    """
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username FROM users WHERE email = ?;", (req.email.strip().lower(),))
    user = cursor.fetchone()
    if not user:
        conn.close()
        # Return success message to avoid email enumeration
        return {"status": "success", "message": "If an owner account with this email exists, recovery instructions have been prepared."}

    token = secrets.token_urlsafe(32)
    expiry = (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat()
    cursor.execute("UPDATE users SET recovery_token = ?, recovery_expiry = ? WHERE id = ?;", (token, expiry, user["id"]))
    conn.commit()
    conn.close()

    log_audit("PASSWORD_RECOVERY_REQUEST", "USER", user["username"], f"Generated recovery token for {req.email}", user["username"], request.client.host if request.client else "")

    return {
        "status": "success",
        "message": "Recovery token generated successfully.",
        "recovery_token": token,
        "recovery_url": f"/admin/reset-password?token={token}"
    }

@app.post("/api/admin/reset-password-confirm")
async def confirm_password_reset(data: PasswordResetConfirm, request: Request):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, recovery_expiry FROM users WHERE recovery_token = ?;", (data.token,))
    user = cursor.fetchone()
    if not user:
        conn.close()
        raise HTTPException(status_code=400, detail="Invalid recovery token")

    now_iso = datetime.now(timezone.utc).isoformat()
    if user["recovery_expiry"] and now_iso > user["recovery_expiry"]:
        conn.close()
        raise HTTPException(status_code=400, detail="Recovery token has expired")

    new_hash = hash_password(data.new_password)
    cursor.execute("UPDATE users SET password_hash = ?, recovery_token = NULL, recovery_expiry = NULL WHERE id = ?;", (new_hash, user["id"]))
    conn.commit()
    conn.close()

    log_audit("PASSWORD_RESET_SUCCESS", "USER", user["username"], "Password reset completed via token", user["username"], request.client.host if request.client else "")
    return {"status": "success", "message": "Password reset successfully. You can now log in with your new password."}

# -------------------------------------------------------------
# DASHBOARD OVERVIEW & ANALYTICS API
# -------------------------------------------------------------
@app.get("/api/admin/dashboard")
async def get_dashboard_metrics(
    period: str = Query("30d", enum=["today", "7d", "30d", "all", "custom"]),
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    current_user: Dict = Depends(get_current_admin)
):
    """
    Computes real metrics with Date Filters:
    - Visitors, sessions, views, add to carts, checkout starts
    - Orders breakdown (Paid, Pending, Failed, Cancelled, Refunded)
    - Books sold, Gross sales, Discounts, Refunds, Net collected revenue
    - Average Order Value, Conversion Rate
    - WhatsApp Clicks (distinct sessions vs total)
    """
    conn = get_db()
    cursor = conn.cursor()

    now = datetime.now(timezone.utc)
    if period == "today":
        since = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    elif period == "7d":
        since = (now - timedelta(days=7)).isoformat()
    elif period == "30d":
        since = (now - timedelta(days=30)).isoformat()
    elif period == "custom" and start_date:
        since = start_date
    else:
        since = "2020-01-01T00:00:00"

    until = end_date if (period == "custom" and end_date) else "2099-12-31T23:59:59"

    # Orders aggregation
    cursor.execute("""
        SELECT
            COUNT(*) as total_orders,
            SUM(CASE WHEN payment_status = 'paid' THEN 1 ELSE 0 END) as paid_orders,
            SUM(CASE WHEN payment_status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
            SUM(CASE WHEN payment_status = 'failed' THEN 1 ELSE 0 END) as failed_orders,
            SUM(CASE WHEN payment_status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_orders,
            SUM(CASE WHEN payment_status = 'refunded' THEN 1 ELSE 0 END) as refunded_orders,
            SUM(CASE WHEN payment_status = 'paid' THEN subtotal ELSE 0 END) as gross_sales,
            SUM(CASE WHEN payment_status = 'paid' THEN discount_amount ELSE 0 END) as total_discounts,
            SUM(CASE WHEN payment_status = 'refunded' THEN refund_amount ELSE 0 END) as total_refunds,
            SUM(CASE WHEN payment_status = 'paid' THEN total_amount ELSE 0 END) as net_collected_revenue
        FROM orders
        WHERE created_at >= ? AND created_at <= ?;
    """, (since, until))
    order_stats = dict(cursor.fetchone())

    gross = order_stats["gross_sales"] or 0.0
    discounts = order_stats["total_discounts"] or 0.0
    refunds = order_stats["total_refunds"] or 0.0
    net_revenue = order_stats["net_collected_revenue"] or 0.0
    paid_count = order_stats["paid_orders"] or 0
    avg_order_val = (net_revenue / paid_count) if paid_count > 0 else 0.0

    # Calculate Books Sold from paid order items
    cursor.execute("""
        SELECT items_json FROM orders WHERE payment_status = 'paid' AND created_at >= ? AND created_at <= ?;
    """, (since, until))
    paid_rows = cursor.fetchall()
    books_sold = 0
    book_sales_counter = {}
    for r in paid_rows:
        try:
            items = json.loads(r["items_json"])
            for it in items:
                qty = int(it.get("qty", 1))
                books_sold += qty
                title = it.get("title", "Unknown")
                book_sales_counter[title] = book_sales_counter.get(title, 0) + qty
        except Exception:
            pass

    # Events breakdown
    cursor.execute("""
        SELECT
            SUM(CASE WHEN event_type = 'page_view' THEN 1 ELSE 0 END) as page_views,
            COUNT(DISTINCT session_id) as total_sessions,
            SUM(CASE WHEN event_type = 'view_content' THEN 1 ELSE 0 END) as book_views,
            SUM(CASE WHEN event_type = 'add_to_cart' THEN 1 ELSE 0 END) as add_to_carts,
            SUM(CASE WHEN event_type = 'initiate_checkout' THEN 1 ELSE 0 END) as checkouts_started,
            SUM(CASE WHEN event_type = 'whatsapp_click' THEN 1 ELSE 0 END) as whatsapp_total_clicks
        FROM events
        WHERE created_at >= ? AND created_at <= ?;
    """, (since, until))
    ev_stats = dict(cursor.fetchone())

    # WhatsApp distinct sessions
    cursor.execute("""
        SELECT COUNT(DISTINCT session_id) as wa_distinct_sessions
        FROM events
        WHERE event_type = 'whatsapp_click' AND created_at >= ? AND created_at <= ?;
    """, (since, until))
    wa_distinct = cursor.fetchone()["wa_distinct_sessions"] or 0

    # Distinct customers & messages
    cursor.execute("SELECT COUNT(*) as cnt FROM customers;")
    total_customers = cursor.fetchone()["cnt"]

    cursor.execute("SELECT COUNT(*) as cnt FROM messages WHERE status = 'new';")
    new_messages = cursor.fetchone()["cnt"]

    # Conversion Rate: Paid Orders / Unique Sessions (or Page Views if no session)
    denom = ev_stats["total_sessions"] or ev_stats["page_views"] or 0
    conversion_rate = (paid_count / denom * 100) if denom > 0 else 0.0

    # Recent 5 Orders
    cursor.execute("""
        SELECT id, customer_name, customer_email, total_amount, currency, payment_status, payment_method, created_at
        FROM orders
        ORDER BY created_at DESC
        LIMIT 6;
    """)
    recent_orders = [dict(r) for r in cursor.fetchall()]

    # Traffic Sources
    cursor.execute("""
        SELECT COALESCE(NULLIF(utm_source, ''), 'Direct / Organic') as source, COUNT(*) as visits
        FROM events
        WHERE created_at >= ? AND created_at <= ?
        GROUP BY source
        ORDER BY visits DESC
        LIMIT 5;
    """, (since, until))
    traffic_sources = [dict(r) for r in cursor.fetchall()]

    conn.close()

    return {
        "period": period,
        "since": since,
        "traffic": {
            "page_views": ev_stats["page_views"] or 0,
            "unique_sessions": ev_stats["total_sessions"] or 0,
            "book_views": ev_stats["book_views"] or 0,
            "add_to_carts": ev_stats["add_to_carts"] or 0,
            "checkout_starts": ev_stats["checkouts_started"] or 0,
            "conversion_rate_pct": round(conversion_rate, 2),
            "conversion_formula": "Paid Orders / Unique Sessions"
        },
        "sales": {
            "total_orders": order_stats["total_orders"] or 0,
            "paid_orders": paid_count,
            "pending_orders": order_stats["pending_orders"] or 0,
            "failed_orders": order_stats["failed_orders"] or 0,
            "cancelled_orders": order_stats["cancelled_orders"] or 0,
            "refunded_orders": order_stats["refunded_orders"] or 0,
            "books_sold_count": books_sold,
            "gross_sales": gross,
            "discounts": discounts,
            "refunds": refunds,
            "net_collected_revenue": net_revenue,
            "currency": "PKR",
            "revenue_calculation_note": "Net Collected = Paid Gross Sales - Discounts - Refunds",
            "average_paid_order_value": round(avg_order_val, 2)
        },
        "whatsapp": {
            "total_clicks": ev_stats["whatsapp_total_clicks"] or 0,
            "distinct_sessions": wa_distinct,
            "label": "WhatsApp button clicks (does not imply confirmed messages received)"
        },
        "records": {
            "registered_customers": total_customers,
            "new_website_messages": new_messages
        },
        "recent_orders": recent_orders,
        "traffic_sources": traffic_sources,
        "best_selling_books": [{"title": k, "sold": v} for k, v in sorted(book_sales_counter.items(), key=lambda x: x[1], reverse=True)[:5]]
    }

# -------------------------------------------------------------
# BOOK MANAGEMENT APIS
# -------------------------------------------------------------
@app.get("/api/admin/books")
async def admin_list_books(
    search: Optional[str] = None,
    status_filter: Optional[str] = None,
    category: Optional[str] = None,
    current_user: Dict = Depends(get_current_admin)
):
    conn = get_db()
    cursor = conn.cursor()
    query = "SELECT * FROM books WHERE 1=1"
    params = []

    if status_filter:
        query += " AND status = ?"
        params.append(status_filter)
    if category and category != "all":
        query += " AND category = ?"
        params.append(category)
    if search:
        query += " AND (title LIKE ? OR author LIKE ? OR tags LIKE ?)"
        s = f"%{search.strip()}%"
        params.extend([s, s, s])

    query += " ORDER BY display_order ASC, id ASC;"
    cursor.execute(query, params)
    books = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return {"books": books}

@app.post("/api/admin/books")
async def admin_create_book(book: BookCreateUpdate, request: Request, current_user: Dict = Depends(get_current_admin)):
    conn = get_db()
    cursor = conn.cursor()
    now_iso = datetime.now(timezone.utc).isoformat()

    # Check slug uniqueness
    cursor.execute("SELECT id FROM books WHERE slug = ?;", (book.slug.strip(),))
    if cursor.fetchone():
        conn.close()
        raise HTTPException(status_code=400, detail="A book with this slug already exists")

    cursor.execute("""
        INSERT INTO books (
            slug, title, author, short_description, full_description, cover_style,
            cover_image, private_pdf_filename, sample_pdf_filename, price, sale_price,
            currency, category, tags, language, page_count, status, is_featured,
            display_order, seo_title, seo_description, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    """, (
        book.slug.strip(), book.title.strip(), book.author, book.short_description.strip(),
        book.full_description.strip(), book.cover_style or "c0", book.cover_image,
        book.private_pdf_filename or f"{book.slug}.pdf", book.sample_pdf_filename,
        book.price, book.sale_price, book.currency or "PKR", book.category, book.tags,
        book.language or "English", book.page_count or 100, book.status or "published",
        book.is_featured or 1, book.display_order or 0, book.seo_title, book.seo_description,
        now_iso, now_iso
    ))
    new_id = cursor.lastrowid
    conn.commit()
    conn.close()

    log_audit("CREATE_BOOK", "BOOK", str(new_id), f"Created book '{book.title}'", current_user["username"], request.client.host if request.client else "")
    return {"status": "created", "book_id": new_id}

@app.put("/api/admin/books/{book_id}")
async def admin_update_book(book_id: int, book: BookCreateUpdate, request: Request, current_user: Dict = Depends(get_current_admin)):
    conn = get_db()
    cursor = conn.cursor()
    now_iso = datetime.now(timezone.utc).isoformat()

    cursor.execute("SELECT id FROM books WHERE id = ?;", (book_id,))
    if not cursor.fetchone():
        conn.close()
        raise HTTPException(status_code=404, detail="Book not found")

    cursor.execute("""
        UPDATE books SET
            title = ?, author = ?, short_description = ?, full_description = ?,
            cover_style = ?, cover_image = ?, private_pdf_filename = ?, sample_pdf_filename = ?,
            price = ?, sale_price = ?, currency = ?, category = ?, tags = ?,
            language = ?, page_count = ?, status = ?, is_featured = ?, display_order = ?,
            seo_title = ?, seo_description = ?, updated_at = ?
        WHERE id = ?;
    """, (
        book.title.strip(), book.author, book.short_description.strip(), book.full_description.strip(),
        book.cover_style, book.cover_image, book.private_pdf_filename, book.sample_pdf_filename,
        book.price, book.sale_price, book.currency or "PKR", book.category, book.tags,
        book.language, book.page_count, book.status, book.is_featured, book.display_order,
        book.seo_title, book.seo_description, now_iso, book_id
    ))
    conn.commit()
    conn.close()

    log_audit("UPDATE_BOOK", "BOOK", str(book_id), f"Updated book '{book.title}'", current_user["username"], request.client.host if request.client else "")
    return {"status": "updated", "book_id": book_id}

@app.post("/api/admin/books/{book_id}/archive")
async def admin_archive_book(book_id: int, request: Request, current_user: Dict = Depends(get_current_admin)):
    conn = get_db()
    cursor = conn.cursor()
    now_iso = datetime.now(timezone.utc).isoformat()
    cursor.execute("UPDATE books SET status = 'archived', updated_at = ? WHERE id = ?;", (now_iso, book_id))
    conn.commit()
    conn.close()

    log_audit("ARCHIVE_BOOK", "BOOK", str(book_id), "Archived book from active sale", current_user["username"], request.client.host if request.client else "")
    return {"status": "archived"}

@app.post("/api/admin/books/{book_id}/restore")
async def admin_restore_book(book_id: int, request: Request, current_user: Dict = Depends(get_current_admin)):
    conn = get_db()
    cursor = conn.cursor()
    now_iso = datetime.now(timezone.utc).isoformat()
    cursor.execute("UPDATE books SET status = 'published', updated_at = ? WHERE id = ?;", (now_iso, book_id))
    conn.commit()
    conn.close()

    log_audit("RESTORE_BOOK", "BOOK", str(book_id), "Restored archived book to published state", current_user["username"], request.client.host if request.client else "")
    return {"status": "restored"}

@app.post("/api/admin/upload-file")
async def upload_file(
    file_type: str = Form("private_pdf"), # private_pdf, sample_pdf, cover
    file: UploadFile = File(...),
    current_user: Dict = Depends(get_current_admin)
):
    safe_name = os.path.basename(file.filename)
    if file_type == "private_pdf":
        target_dir = STORAGE_PRIVATE
    elif file_type == "sample_pdf":
        target_dir = STORAGE_SAMPLES
    else:
        target_dir = STORAGE_COVERS

    dest_path = os.path.join(target_dir, safe_name)
    with open(dest_path, "wb") as f:
        f.write(await file.read())

    return {"status": "uploaded", "filename": safe_name, "type": file_type}

# -------------------------------------------------------------
# ORDERS & PAYMENTS APIS
# -------------------------------------------------------------
@app.get("/api/admin/orders")
async def admin_list_orders(
    search: Optional[str] = None,
    status_filter: Optional[str] = None,
    current_user: Dict = Depends(get_current_admin)
):
    conn = get_db()
    cursor = conn.cursor()
    query = "SELECT * FROM orders WHERE 1=1"
    params = []

    if status_filter:
        query += " AND payment_status = ?"
        params.append(status_filter)
    if search:
        query += " AND (id LIKE ? OR customer_name LIKE ? OR customer_email LIKE ?)"
        s = f"%{search.strip()}%"
        params.extend([s, s, s])

    query += " ORDER BY created_at DESC;"
    cursor.execute(query, params)
    orders = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return {"orders": orders}

@app.get("/api/admin/orders/{order_id}")
async def admin_get_order(order_id: str, current_user: Dict = Depends(get_current_admin)):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM orders WHERE id = ?;", (order_id,))
    order = cursor.fetchone()
    conn.close()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return {"order": dict(order)}

@app.post("/api/admin/orders/{order_id}/confirm-payment")
async def admin_confirm_payment(order_id: str, request: Request, current_user: Dict = Depends(get_current_admin)):
    """
    Authorized Manual / Server-side payment confirmation.
    Marks order 'paid', grants download access with token,
    updates customer spend, records audit log, and dispatches Meta Purchase event.
    """
    conn = get_db()
    cursor = conn.cursor()
    now_iso = datetime.now(timezone.utc).isoformat()

    cursor.execute("SELECT * FROM orders WHERE id = ?;", (order_id,))
    order = cursor.fetchone()
    if not order:
        conn.close()
        raise HTTPException(status_code=404, detail="Order not found")

    if order["payment_status"] == "paid":
        conn.close()
        return {"status": "already_paid", "message": "Order is already paid"}

    # Generate or refresh download token
    token = order["download_token"] or secrets.token_urlsafe(24)
    expiry = (datetime.now(timezone.utc) + timedelta(hours=72)).isoformat()

    cursor.execute("""
        UPDATE orders SET
            payment_status = 'paid',
            fulfillment_status = 'fulfilled',
            download_granted = 1,
            download_token = ?,
            download_token_expiry = ?,
            updated_at = ?
        WHERE id = ?;
    """, (token, expiry, now_iso, order_id))

    # Update customer record
    cursor.execute("""
        UPDATE customers SET
            total_spent = total_spent + ?,
            last_order_at = ?
        WHERE email = ?;
    """, (order["total_amount"], now_iso, order["customer_email"]))

    conn.commit()
    conn.close()

    log_audit("CONFIRM_PAYMENT", "ORDER", order_id, f"Payment confirmed by owner. Total: PKR {order['total_amount']}", current_user["username"], request.client.host if request.client else "")

    # Meta CAPI Purchase event
    send_capi_event(
        event_name="Purchase",
        event_id=f"pur_{order_id}",
        user_data={"email": order["customer_email"], "phone": order["customer_phone"]},
        custom_data={"value": order["total_amount"], "currency": order["currency"], "order_id": order_id}
    )

    return {
        "status": "success",
        "order_id": order_id,
        "payment_status": "paid",
        "download_token": token,
        "download_url": f"/download/{token}"
    }

@app.post("/api/admin/orders/{order_id}/refund")
async def admin_refund_order(order_id: str, request: Request, current_user: Dict = Depends(get_current_admin)):
    conn = get_db()
    cursor = conn.cursor()
    now_iso = datetime.now(timezone.utc).isoformat()

    cursor.execute("SELECT * FROM orders WHERE id = ?;", (order_id,))
    order = cursor.fetchone()
    if not order:
        conn.close()
        raise HTTPException(status_code=404, detail="Order not found")

    cursor.execute("""
        UPDATE orders SET
            payment_status = 'refunded',
            refund_amount = total_amount,
            download_granted = 0,
            updated_at = ?
        WHERE id = ?;
    """, (now_iso, order_id))

    cursor.execute("""
        UPDATE customers SET
            total_spent = MAX(0, total_spent - ?)
        WHERE email = ?;
    """, (order["total_amount"], order["customer_email"]))

    conn.commit()
    conn.close()

    log_audit("REFUND_ORDER", "ORDER", order_id, f"Refunded PKR {order['total_amount']}. Download revoked.", current_user["username"], request.client.host if request.client else "")
    return {"status": "refunded"}

@app.get("/api/admin/orders/export/csv")
async def export_orders_csv(current_user: Dict = Depends(get_current_admin)):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id, customer_name, customer_email, customer_phone, total_amount, currency, payment_status, payment_method, utm_source, utm_campaign, created_at FROM orders ORDER BY created_at DESC;")
    rows = cursor.fetchall()
    conn.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Order ID", "Customer Name", "Email", "Phone", "Total Amount", "Currency", "Payment Status", "Payment Method", "UTM Source", "UTM Campaign", "Created At"])
    for r in rows:
        writer.writerow([r["id"], r["customer_name"], r["customer_email"], r["customer_phone"], r["total_amount"], r["currency"], r["payment_status"], r["payment_method"], r["utm_source"], r["utm_campaign"], r["created_at"]])

    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=readora-orders-{datetime.now().strftime('%Y%m%d')}.csv"}
    )

# -------------------------------------------------------------
# CUSTOMERS & MESSAGES APIS
# -------------------------------------------------------------
@app.get("/api/admin/customers")
async def admin_list_customers(search: Optional[str] = None, current_user: Dict = Depends(get_current_admin)):
    conn = get_db()
    cursor = conn.cursor()
    query = "SELECT * FROM customers WHERE 1=1"
    params = []
    if search:
        query += " AND (name LIKE ? OR email LIKE ?)"
        s = f"%{search.strip()}%"
        params.extend([s, s])
    query += " ORDER BY total_spent DESC, created_at DESC;"
    cursor.execute(query, params)
    customers = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return {"customers": customers}

@app.get("/api/admin/messages")
async def admin_list_messages(status_filter: Optional[str] = None, current_user: Dict = Depends(get_current_admin)):
    conn = get_db()
    cursor = conn.cursor()
    query = "SELECT * FROM messages WHERE 1=1"
    params = []
    if status_filter:
        query += " AND status = ?"
        params.append(status_filter)
    query += " ORDER BY created_at DESC;"
    cursor.execute(query, params)
    messages = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return {"messages": messages}

@app.put("/api/admin/messages/{message_id}")
async def admin_update_message(
    message_id: int,
    payload: Dict[str, Any],
    request: Request,
    current_user: Dict = Depends(get_current_admin)
):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM messages WHERE id = ?;", (message_id,))
    if not cursor.fetchone():
        conn.close()
        raise HTTPException(status_code=404, detail="Message not found")

    new_status = payload.get("status")
    admin_notes = payload.get("admin_notes")

    if new_status:
        cursor.execute("UPDATE messages SET status = ? WHERE id = ?;", (new_status, message_id))
    if admin_notes is not None:
        cursor.execute("UPDATE messages SET admin_notes = ? WHERE id = ?;", (admin_notes, message_id))

    conn.commit()
    conn.close()

    log_audit("UPDATE_MESSAGE", "MESSAGE", str(message_id), f"Updated message status to '{new_status}'", current_user["username"], request.client.host if request.client else "")
    return {"status": "updated"}

# -------------------------------------------------------------
# WHATSAPP & META TRACKING APIS
# -------------------------------------------------------------
@app.get("/api/admin/whatsapp")
async def admin_whatsapp_stats(current_user: Dict = Depends(get_current_admin)):
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            COUNT(*) as total_clicks,
            COUNT(DISTINCT session_id) as distinct_sessions
        FROM events
        WHERE event_type = 'whatsapp_click';
    """)
    totals = dict(cursor.fetchone())

    # Breakdown by placement / button
    cursor.execute("""
        SELECT COALESCE(NULLIF(placement, ''), 'Floating CTA') as placement_name, COUNT(*) as click_count
        FROM events
        WHERE event_type = 'whatsapp_click'
        GROUP BY placement_name
        ORDER BY click_count DESC;
    """)
    placements = [dict(r) for r in cursor.fetchall()]

    # Breakdown by book
    cursor.execute("""
        SELECT COALESCE(NULLIF(book_title, ''), 'General Store Inquiry') as book_name, COUNT(*) as click_count
        FROM events
        WHERE event_type = 'whatsapp_click'
        GROUP BY book_name
        ORDER BY click_count DESC;
    """)
    by_book = [dict(r) for r in cursor.fetchall()]

    # Breakdown by UTM Campaign
    cursor.execute("""
        SELECT COALESCE(NULLIF(utm_campaign, ''), 'None / Direct') as campaign_name, COUNT(*) as click_count
        FROM events
        WHERE event_type = 'whatsapp_click'
        GROUP BY campaign_name
        ORDER BY click_count DESC;
    """)
    by_campaign = [dict(r) for r in cursor.fetchall()]

    conn.close()

    return {
        "summary": {
            "total_clicks": totals["total_clicks"],
            "distinct_sessions": totals["distinct_sessions"],
            "label": "WhatsApp button clicks (tracked on this website; does not access private chat messages)"
        },
        "placements": placements,
        "by_book": by_book,
        "by_campaign": by_campaign,
        "contact_target": {
            "phone": "03374693712",
            "international": "+92 337 4693712",
            "url": "https://wa.me/923374693712"
        }
    }

@app.get("/api/admin/integrations/meta")
async def admin_get_meta_status(current_user: Dict = Depends(get_current_admin)):
    config = get_meta_config()
    test_res = test_meta_connection()
    return {
        "config": {
            "pixel_id": config["pixel_id"],
            "enabled": config["enabled"],
            "has_capi_token": bool(config["access_token"]),
            "test_event_code": config["test_event_code"]
        },
        "status": test_res
    }

@app.post("/api/admin/integrations/meta")
async def admin_save_meta_config(payload: Dict[str, Any], request: Request, current_user: Dict = Depends(get_current_admin)):
    conn = get_db()
    cursor = conn.cursor()
    now_iso = datetime.now(timezone.utc).isoformat()

    updates = {
        "meta_pixel_id": str(payload.get("pixel_id", "")).strip(),
        "meta_pixel_enabled": "1" if payload.get("enabled") else "0",
        "meta_test_event_code": str(payload.get("test_event_code", "")).strip()
    }
    if "capi_token" in payload and payload["capi_token"]:
        updates["meta_capi_token"] = str(payload["capi_token"]).strip()

    for k, v in updates.items():
        cursor.execute("INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, ?);", (k, v, now_iso))

    conn.commit()
    conn.close()

    log_audit("UPDATE_META_INTEGRATION", "SETTINGS", "meta", f"Pixel enabled: {updates['meta_pixel_enabled']}", current_user["username"], request.client.host if request.client else "")
    return {"status": "saved", "connection": test_meta_connection()}

# -------------------------------------------------------------
# SETTINGS & AUDIT LOGS APIS
# -------------------------------------------------------------
@app.get("/api/admin/settings")
async def admin_get_settings(current_user: Dict = Depends(get_current_admin)):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT key, value FROM settings;")
    settings = {r["key"]: r["value"] for r in cursor.fetchall()}
    conn.close()
    # Mask CAPI token for security
    if "meta_capi_token" in settings and settings["meta_capi_token"]:
        settings["meta_capi_token_masked"] = settings["meta_capi_token"][:6] + "..." + settings["meta_capi_token"][-4:]
        del settings["meta_capi_token"]
    return {"settings": settings}

@app.post("/api/admin/settings")
async def admin_save_settings(data: SettingsUpdateRequest, request: Request, current_user: Dict = Depends(get_current_admin)):
    conn = get_db()
    cursor = conn.cursor()
    now_iso = datetime.now(timezone.utc).isoformat()

    for k, v in data.settings.items():
        cursor.execute("INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, ?);", (k, str(v), now_iso))

    conn.commit()
    conn.close()

    log_audit("UPDATE_SETTINGS", "SETTINGS", "store", f"Updated {len(data.settings)} settings", current_user["username"], request.client.host if request.client else "")
    return {"status": "saved"}

@app.get("/api/admin/audit-logs")
async def admin_list_audit_logs(limit: int = 50, current_user: Dict = Depends(get_current_admin)):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT ?;", (min(limit, 100),))
    logs = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return {"audit_logs": logs}

# -------------------------------------------------------------
# ADMIN DASHBOARD FRONTEND ROUTE
# -------------------------------------------------------------
@app.get("/admin", response_class=HTMLResponse)
@app.get("/admin/", response_class=HTMLResponse)
@app.get("/admin/{path:path}", response_class=HTMLResponse)
async def serve_admin_spa(path: str = ""):
    admin_index = os.path.join(PUBLIC_DIR, "admin", "index.html")
    if os.path.exists(admin_index):
        with open(admin_index, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    return HTMLResponse("<h1>Readora Owner Admin</h1><p>Admin UI building...</p>")

# Mount static folders if present
app.mount("/static", StaticFiles(directory=STORAGE_COVERS), name="covers")
app.mount("/admin-assets", StaticFiles(directory=os.path.join(PUBLIC_DIR, "admin")), name="admin_assets")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="0.0.0.0", port=8080, reload=False)
